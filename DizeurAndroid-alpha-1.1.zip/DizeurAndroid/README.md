# DIZEUR Android — prototype Alpha 1.1

Application Android native en Kotlin + Jetpack Compose destinée à piloter Deezer à la voix après le mot de réveil « Dizeur ».

## Fonctions codées dans le prototype

- Interface sombre bleu holographique.
- Service vocal de premier plan avec notification persistante et action d'arrêt.
- Reconnaissance vocale en français : moteur Android embarqué lorsqu'il est disponible sur le téléphone, sinon moteur Android standard avec demande de préférence hors ligne.
- Recherche du mot « Dizeur » dans la transcription.
- Commandes : lecture/reprise, pause, suivant, précédent, aléatoire, volume +/- et volume en pourcentage.
- Ouverture de Deezer et ouverture de sa page de recherche pour un artiste, un titre ou un genre.
- Contrôle des sessions multimédias Android uniquement lorsque la session Deezer est identifiée (aucun repli automatique vers une autre application musicale).
- Réponse vocale française via la synthèse vocale Android.

## Limites importantes

1. **Ce n'est pas encore une version finale.** Le code source est fourni, mais aucune compilation Android ni aucun test sur téléphone n'a été réalisé dans l'environnement de préparation.
2. **Le mot de réveil n'est pas encore détecté par un modèle acoustique local dédié.** Le prototype utilise `SpeechRecognizer` Android et cherche « Dizeur » dans le texte reconnu. Sur Android 12 et versions ultérieures, il sélectionne le moteur embarqué si le téléphone en déclare un disponible. Sinon, il utilise le moteur Android standard ; `EXTRA_PREFER_OFFLINE` reste une préférence, pas une garantie de fonctionnement hors ligne.
3. **Écoute en arrière-plan.** L'utilisateur doit démarrer le service depuis l'application visible et accorder le microphone. Android affiche une notification persistante pour le service microphone. Les restrictions d'économie d'énergie du fabricant peuvent interrompre le service. Le service ne se relance pas automatiquement après une fermeture système : il faut le redémarrer depuis l'application.
4. **Deezer.** Deezer doit être installé et connecté. La recherche ouvre la page de recherche Deezer ; elle ne garantit pas le démarrage direct du titre. Les commandes de lecture dépendent de la présence d'une session multimédia Deezer active et des commandes que cette session accepte.
5. **Aléatoire.** Le mode aléatoire est basculé uniquement si la session Deezer annonce prendre en charge `setShuffleMode`. Le changement réel reste à vérifier avec la version de Deezer installée.
6. **Volume.** Le volume modifié est celui du flux multimédia Android, pas un réglage interne indépendant de Deezer.

## Autorisations Android

- `RECORD_AUDIO` : reconnaissance vocale.
- `FOREGROUND_SERVICE` et `FOREGROUND_SERVICE_MICROPHONE` : service vocal de premier plan.
- Accès spécial « Notifications » : lecture des sessions multimédias Android.
- `INTERNET` : ouverture des pages Deezer.

L'accès aux notifications est accordé manuellement dans les paramètres Android. Il ne faut pas activer cette permission pour une application non fiable.

## Compilation

Environnement prévu : JDK 17, Gradle 8.13, Android Gradle Plugin 8.10.1, Kotlin 2.1.20 et Android SDK 36.

Dans Android Studio :

1. Ouvrir le dossier `DizeurAndroid`.
2. Synchroniser le projet Gradle.
3. Connecter un téléphone Android avec le débogage USB activé, ou lancer un émulateur.
4. Lancer la configuration `app`.
5. Pour générer un APK : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

La CI GitHub est configurée dans `.github/workflows/android-build.yml` pour compiler l'APK de débogage lorsqu'un dépôt GitHub est configuré et que le workflow est exécuté.

## Tests

Voir :
- [`docs/COMMANDES.md`](docs/COMMANDES.md)
- [`docs/PLAN_DE_TEST.md`](docs/PLAN_DE_TEST.md)

## Structure

- `app/src/main/java/fr/dizeur/app/MainActivity.kt` : interface et autorisations.
- `app/src/main/java/fr/dizeur/app/VoiceWakeService.kt` : service vocal, mot de réveil, commandes et synthèse vocale.
- `app/src/main/java/fr/dizeur/app/MediaControllerBridge.kt` : commandes multimédias Android et volume.
- `app/src/main/java/fr/dizeur/app/DizeurNotificationListener.kt` : accès Android aux sessions multimédias.

## Suite indispensable avant la version test

- Compiler le projet avec Android SDK.
- Installer l'APK sur le téléphone cible.
- Valider les commandes et la session Deezer réelle.
- Intégrer un moteur de détection de mot-clé local (KWS) avec modèle adapté pour « Dizeur ».
- Mesurer autonomie, faux déclenchements et stabilité écran éteint.
