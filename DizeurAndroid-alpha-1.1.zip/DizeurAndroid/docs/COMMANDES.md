# DIZEUR — commandes vocales du prototype

Prononcer le mot de réveil « Dizeur », puis la commande. Si le moteur ne restitue que le mot de réveil, DIZEUR demande ensuite la commande.

| Catégorie | Exemples |
|---|---|
| Ouvrir Deezer | « Dizeur, ouvre Deezer » ; « Dizeur, lance Deezer » |
| Rechercher | « Dizeur, mets du jazz » ; « Dizeur, joue Stromae » ; « Dizeur, recherche Daft Punk » |
| Lecture | « Dizeur, reprends » ; « Dizeur, lecture » |
| Pause | « Dizeur, pause » ; « Dizeur, arrête la musique » |
| Navigation | « Dizeur, suivant » ; « Dizeur, précédent » |
| Aléatoire | « Dizeur, musique aléatoire » ; « Dizeur, mélange » (bascule si Deezer prend en charge la commande) |
| Volume | « Dizeur, monte le son » ; « Dizeur, baisse le son » ; « Dizeur, volume à 40 » |

Les commandes multimédias sont envoyées uniquement à une session Android identifiée comme Deezer. Si aucune session Deezer n'est active, DIZEUR le signale et ne commande pas une autre application musicale. Les fonctions disponibles dépendent des capacités exposées par la version de Deezer installée. La recherche ouvre une page de résultats ; elle ne lance pas automatiquement la lecture du résultat.
