# DIZEUR 1.1 — plan de validation Android

Ce document décrit les contrôles à effectuer sur le téléphone cible. Aucun test sur appareil physique n'a encore été exécuté.

## Pré-requis

- Android 8.0 (API 26) ou version ultérieure.
- Deezer installé et connecté.
- Service de reconnaissance vocale Android disponible en français ; moteur embarqué conseillé si le téléphone en propose un.
- Autorisation microphone accordée à DIZEUR.
- Accès aux notifications accordé à DIZEUR pour lire les sessions multimédias.
- Batterie non restreinte pour DIZEUR pendant les essais longue durée (réglage dépendant du fabricant).

## Installation et démarrage

1. Installer l'APK de débogage générée par Android Studio.
2. Ouvrir DIZEUR et accorder l'autorisation microphone.
3. Activer l'accès aux notifications depuis les paramètres Android.
4. Revenir dans DIZEUR et démarrer l'écoute.
5. Vérifier la notification persistante « DIZEUR est en écoute ».
6. Dire « Dizeur » puis vérifier la réponse vocale.

## Scénarios fonctionnels

| N° | Commande | Résultat attendu | Résultat réel |
|---:|---|---|---|
| 1 | « Dizeur, ouvre Deezer » | Deezer s'ouvre | À tester |
| 2 | « Dizeur, mets du jazz » | Recherche Deezer du terme demandé | À tester |
| 3 | « Dizeur, pause » | Le lecteur actif se met en pause | À tester |
| 4 | « Dizeur, reprends » | Le lecteur actif reprend | À tester |
| 5 | « Dizeur, suivant » | Passage au titre suivant | À tester |
| 6 | « Dizeur, précédent » | Retour au titre précédent | À tester |
| 7 | « Dizeur, musique aléatoire » | Bascule du mode aléatoire si la session Deezer annonce cette capacité | À tester |
| 8 | « Dizeur, monte le son » | Volume multimédia augmenté | À tester |
| 9 | « Dizeur, baisse le son » | Volume multimédia diminué | À tester |
| 10 | « Dizeur, volume à 40 » | Volume multimédia réglé à environ 40 % | À tester |

## Scénarios de stabilité

- Laisser l'écoute active 30 minutes écran allumé.
- Refaire l'essai écran éteint pendant 30 minutes.
- Tester avec Deezer en lecture puis en pause.
- Tester avec un casque ou une enceinte Bluetooth connectée au téléphone.
- Vérifier la reprise après une interruption audio (appel, notification vocale).
- Vérifier que les commandes ne pilotent pas une autre application musicale si Deezer n'a pas de session active.
- Vérifier que le mode aléatoire change réellement d'état lorsqu'il est annoncé comme pris en charge.
- Vérifier l'impact sur la batterie sur une période de 2 heures.
- Vérifier les faux déclenchements dans une conversation normale.

## Critères de validation

La version ne sera considérée comme candidate à la période d'essai d'un mois qu'après :

- compilation sans erreur ;
- installation et démarrage sur le téléphone cible ;
- validation de chaque commande prise en charge ;
- vérification du fonctionnement écran éteint ;
- mesure de la consommation et des faux déclenchements ;
- confirmation claire des limites du moteur de reconnaissance.

## Limites actuelles

Le prototype emploie `SpeechRecognizer` d'Android et recherche le mot « Dizeur » dans les résultats de transcription. Sur Android 12 et versions ultérieures, il choisit le moteur embarqué si le téléphone en déclare un disponible ; sinon il utilise le moteur Android standard. Ce n'est pas une détection acoustique locale spécialisée de mot-clé. Une vraie détection locale continue nécessitera un moteur KWS embarqué et un modèle adapté à « Dizeur », puis des essais sur l'appareil.
