package fr.dizeur.app

import android.Manifest
import android.app.ActivityManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

private val Navy = Color(0xFF070B18)
private val Panel = Color(0xFF111B32)
private val Cyan = Color(0xFF36D9FF)

class MainActivity : ComponentActivity() {
    private fun isVoiceServiceRunning(): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        @Suppress("DEPRECATION")
        return manager.getRunningServices(Int.MAX_VALUE).any {
            it.service.className == VoiceWakeService::class.java.name
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DizeurScreen() }
    }

    override fun onResume() {
        super.onResume()
        // The Compose lifecycle observer below refreshes permissions and service state.
    }

    @androidx.compose.runtime.Composable
    private fun DizeurScreen() {
        var micGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
        var listening by remember { mutableStateOf(isVoiceServiceRunning()) }
        var notificationAccess by remember { mutableStateOf(MediaControllerBridge.hasNotificationAccess(this)) }
        val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }

        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    micGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    notificationAccess = MediaControllerBridge.hasNotificationAccess(this@MainActivity)
                    listening = isVoiceServiceRunning()
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        LaunchedEffect(Unit) {
            micGranted = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            notificationAccess = MediaControllerBridge.hasNotificationAccess(this@MainActivity)
            listening = isVoiceServiceRunning()
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Cyan, onPrimary = Navy, background = Navy, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, secondary = Color(0xFF8AA8FF)
        )) {
            Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
                Column(
                    modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF101E3D), Navy, Color(0xFF050711)))).padding(horizontal = 22.dp, vertical = 26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("DIZEUR", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                            Text("ASSISTANT MUSICAL", color = Cyan, fontSize = 10.sp, letterSpacing = 3.sp)
                        }
                        IconBadge()
                    }
                    Spacer(Modifier.height(8.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(shape = CircleShape, color = Color(0xFF102A49), modifier = Modifier.size(176.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                androidx.compose.material3.Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Cyan, modifier = Modifier.size(72.dp))
                                Text(if (listening) "EN ÉCOUTE" else "EN VEILLE", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            }
                        }
                        Text("Dis simplement « Dizeur »", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Text("Puis donne ta commande musicale.", color = Color(0xFF9AA9C4), fontSize = 14.sp)
                    }
                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text("CONFIGURATION", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            StatusLine("Microphone", if (micGranted) "Autorisé" else "À autoriser", micGranted)
                            StatusLine("Contrôle Deezer", if (notificationAccess) "Accès activé" else "Accès à activer", notificationAccess)
                            Text("L'accès aux notifications permet à Android de transmettre les commandes au lecteur Deezer.", color = Color(0xFF9AA9C4), fontSize = 12.sp)
                        }
                    }
                    Button(
                        enabled = !listening,
                        onClick = {
                            if (!micGranted) micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            else if (!notificationAccess) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            else {
                                try {
                                    ContextCompat.startForegroundService(
                                        this@MainActivity,
                                        Intent(this@MainActivity, VoiceWakeService::class.java)
                                    )
                                    listening = true
                                } catch (_: Exception) {
                                    listening = false
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        androidx.compose.material3.Icon(Icons.Default.Mic, contentDescription = null)
                        Text(if (!micGranted) "AUTORISER LE MICRO" else if (!notificationAccess) "AUTORISER DEEZER" else if (listening) "DIZEUR EST ACTIVÉ" else "ACTIVER DIZEUR", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            stopService(Intent(this@MainActivity, VoiceWakeService::class.java))
                            listening = false
                        }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)
                    ) { Text("ARRÊTER L'ÉCOUTE") }
                    Text("Exemples : « Dizeur, mets du jazz » · « Dizeur, pause » · « Dizeur, volume à 40 »", color = Color(0xFF7F8CA8), fontSize = 11.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.weight(1f))
                    Text("VERSION 1.1 ALPHA  •  ANDROID", color = Color(0xFF52617D), fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun IconBadge() {
    Surface(shape = CircleShape, color = Color(0xFF102A49), modifier = Modifier.size(48.dp)) {
        androidx.compose.material3.Icon(Icons.Default.MusicNote, contentDescription = null, tint = Cyan, modifier = Modifier.padding(12.dp))
    }
}

@androidx.compose.runtime.Composable
private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Text(value, color = if (ok) Color(0xFF64E6B1) else Color(0xFFFFC56B), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
