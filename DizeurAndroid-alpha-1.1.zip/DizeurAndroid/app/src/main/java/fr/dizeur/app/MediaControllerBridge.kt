package fr.dizeur.app

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.provider.Settings
import android.text.TextUtils
import android.media.session.PlaybackState

/** Bridges DIZEUR commands to Deezer's Android media session. */
object MediaControllerBridge {
    private fun listenerComponent(context: Context) =
        ComponentName(context, DizeurNotificationListener::class.java)

    fun hasNotificationAccess(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false

        return TextUtils.SimpleStringSplitter(':').run {
            setString(enabled)
            any { ComponentName.unflattenFromString(it)?.packageName == context.packageName }
        }
    }

    /** Never falls back to another music app: a command must not control Spotify, YouTube, etc. */
    private fun deezerController(context: Context): MediaController? = try {
        val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        manager.getActiveSessions(listenerComponent(context))
            .firstOrNull { it.packageName.contains("deezer", ignoreCase = true) }
    } catch (_: SecurityException) {
        null
    } catch (_: Exception) {
        null
    }

    fun hasDeezerSession(context: Context): Boolean = deezerController(context) != null

    fun playPause(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val playback = controller.playbackState ?: return false
        return if (playback.state == PlaybackState.STATE_PLAYING ||
            playback.state == PlaybackState.STATE_BUFFERING
        ) {
            if (!supports(playback, PlaybackState.ACTION_PAUSE, PlaybackState.ACTION_PLAY_PAUSE)) return false
            controller.transportControls.pause()
            true
        } else {
            if (!supports(playback, PlaybackState.ACTION_PLAY, PlaybackState.ACTION_PLAY_PAUSE)) return false
            controller.transportControls.play()
            true
        }
    }

    fun pause(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val playback = controller.playbackState ?: return false
        if (!supports(playback, PlaybackState.ACTION_PAUSE, PlaybackState.ACTION_PLAY_PAUSE)) return false
        controller.transportControls.pause()
        return true
    }

    fun play(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val playback = controller.playbackState ?: return false
        if (!supports(playback, PlaybackState.ACTION_PLAY, PlaybackState.ACTION_PLAY_PAUSE)) return false
        controller.transportControls.play()
        return true
    }

    fun next(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val playback = controller.playbackState ?: return false
        if (!supports(playback, PlaybackState.ACTION_SKIP_TO_NEXT)) return false
        controller.transportControls.skipToNext()
        return true
    }

    fun previous(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val playback = controller.playbackState ?: return false
        if (!supports(playback, PlaybackState.ACTION_SKIP_TO_PREVIOUS)) return false
        controller.transportControls.skipToPrevious()
        return true
    }

    private fun supports(state: PlaybackState, vararg actions: Long): Boolean =
        actions.any { (state.actions and it) != 0L }

    /** Toggles shuffle instead of always claiming it was enabled. */
    fun toggleShuffle(context: Context): Boolean {
        val controller = deezerController(context) ?: return false
        val state = controller.playbackState ?: return false
        if ((state.actions and PlaybackState.ACTION_SET_SHUFFLE_MODE) == 0L) return false
        val nextMode = if (state.shuffleMode == PlaybackState.SHUFFLE_MODE_ALL) {
            PlaybackState.SHUFFLE_MODE_NONE
        } else {
            PlaybackState.SHUFFLE_MODE_ALL
        }
        controller.transportControls.setShuffleMode(nextMode)
        return true
    }

    fun volume(context: Context, up: Boolean, percent: Int? = null): Boolean = try {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (percent != null) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val target = (max * percent.coerceIn(0, 100) / 100f).toInt()
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        } else {
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
        }
        true
    } catch (_: SecurityException) {
        false
    } catch (_: Exception) {
        false
    }
}
