package fr.dizeur.app

import android.service.notification.NotificationListenerService

/** Android requires the user to enable notification access before DIZEUR can inspect media sessions. */
class DizeurNotificationListener : NotificationListenerService()
