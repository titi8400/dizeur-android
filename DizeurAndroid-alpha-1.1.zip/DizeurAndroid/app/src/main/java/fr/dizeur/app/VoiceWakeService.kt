package fr.dizeur.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import java.text.Normalizer
import java.util.Locale

class VoiceWakeService : Service(), RecognitionListener, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_STOP = "fr.dizeur.app.STOP_WAKE"
        private const val CHANNEL_ID = "dizeur_voice"
        private const val NOTIFICATION_ID = 4101
        private const val TAG = "DizeurVoice"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var awaitingCommand = false
    private var listening = false
    private var speaking = false
    private var destroyed = false
    private var restartRunnable: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "Aucun service de reconnaissance vocale disponible")
            stopSelf()
            return
        }

        recognizer = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
            ) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Création du moteur vocal impossible", e)
            stopSelf()
            return
        }.also { it.setRecognitionListener(this) }

        startListening()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        // A killed microphone service must be restarted explicitly from the visible app.
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Écoute vocale DIZEUR",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Indique que DIZEUR attend son mot de réveil."
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this,
            2,
            Intent(this, VoiceWakeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("DIZEUR est en écoute")
            .setContentText("Prononce « Dizeur » pour donner une commande")
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Arrêter", stop)
            .setOngoing(true)
            .build()
    }

    private fun startListening() {
        if (destroyed || listening || speaking || recognizer == null) return
        cancelRestart()
        val start = Runnable {
            if (destroyed || listening || speaking) return@Runnable
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                }
                listening = true
                recognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Impossible de démarrer l'écoute", e)
                listening = false
                scheduleRestart(1800)
            }
        }
        handler.postDelayed(start, 400)
        restartRunnable = start
    }

    private fun scheduleRestart(delayMs: Long) {
        if (destroyed || speaking) return
        cancelRestart()
        val task = Runnable {
            restartRunnable = null
            listening = false
            startListening()
        }
        restartRunnable = task
        handler.postDelayed(task, delayMs)
    }

    private fun cancelRestart() {
        restartRunnable?.let(handler::removeCallbacks)
        restartRunnable = null
    }

    override fun onReadyForSpeech(params: Bundle?) { }
    override fun onBeginningOfSpeech() { }
    override fun onRmsChanged(rmsdB: Float) { }
    override fun onBufferReceived(buffer: ByteArray?) { }
    override fun onEndOfSpeech() { listening = false }

    override fun onResults(results: Bundle?) {
        listening = false
        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull().orEmpty()
        Log.d(TAG, "Reconnu: $heard")
        if (heard.isBlank()) {
            scheduleRestart(700)
            return
        }
        processSpeech(heard)
        if (!speaking) scheduleRestart(700)
    }

    override fun onError(error: Int) {
        listening = false
        Log.d(TAG, "Erreur reconnaissance: $error")
        val delay = when (error) {
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1600L
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> 2200L
            else -> 900L
        }
        scheduleRestart(delay)
    }

    override fun onPartialResults(partialResults: Bundle?) { }
    override fun onEvent(eventType: Int, params: Bundle?) { }

    private fun processSpeech(raw: String) {
        val normalized = normalize(raw)
        if (normalized.isBlank()) return

        if (awaitingCommand) {
            awaitingCommand = false
            executeCommand(normalized)
            return
        }

        val wakeMatch = Regex("\\bdizeur\\b").find(normalized) ?: return
        val command = normalized.substring(wakeMatch.range.last + 1).trim()
        if (command.isBlank()) {
            awaitingCommand = true
            speak("Oui ?")
        } else {
            executeCommand(command)
        }
    }

    private fun normalize(value: String): String = Normalizer.normalize(
        value.lowercase(Locale.FRENCH),
        Normalizer.Form.NFD
    ).replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9% ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun executeCommand(command: String) {
        when {
            command.contains("pause") || command.contains("arrete la musique") || command == "stop" -> {
                speak(if (MediaControllerBridge.pause(this)) "Pause" else noDeezerSession())
            }
            command.contains("reprends") || command.contains("reprend") ||
                command.contains("lecture") || command.contains("continue") || command == "play" -> {
                speak(if (MediaControllerBridge.play(this)) "Je reprends" else noDeezerSession())
            }
            command.contains("suivant") || command.contains("change de titre") || command == "change" -> {
                speak(if (MediaControllerBridge.next(this)) "Titre suivant" else noDeezerSession())
            }
            command.contains("precedent") || command.contains("titre precedent") -> {
                speak(if (MediaControllerBridge.previous(this)) "Titre précédent" else noDeezerSession())
            }
            command.contains("aleatoire") || command.contains("melange") || command.contains("shuffle") -> {
                speak(
                    if (MediaControllerBridge.toggleShuffle(this)) "Mode aléatoire modifié"
                    else "Le mode aléatoire n'est pas disponible dans la session Deezer actuelle."
                )
            }
            Regex("\\b[0-9]{1,3}\\b").containsMatchIn(command) &&
                (command.contains("volume") || command.contains("son")) -> {
                val percent = Regex("\\b[0-9]{1,3}\\b").find(command)
                    ?.value?.toIntOrNull()?.coerceIn(0, 100) ?: 50
                speak(
                    if (MediaControllerBridge.volume(this, true, percent)) "Volume à $percent pour cent"
                    else "Je ne peux pas modifier le volume."
                )
            }
            command.contains("monte le son") || command.contains("augmente le volume") || command.contains("plus fort") -> {
                speak(if (MediaControllerBridge.volume(this, true)) "J'augmente le volume" else "Je ne peux pas modifier le volume.")
            }
            command.contains("baisse le son") || command.contains("diminue le volume") || command.contains("moins fort") -> {
                speak(if (MediaControllerBridge.volume(this, false)) "Je baisse le volume" else "Je ne peux pas modifier le volume.")
            }
            command.contains("ouvre deezer") || command == "deezer" || command.contains("lance deezer") -> {
                openDeezer()
                speak("J'ouvre Deezer")
            }
            command.startsWith("mets ") || command.startsWith("met ") ||
                command.startsWith("joue ") || command.startsWith("recherche ") -> {
                val query = command.replaceFirst(
                    Regex("^(mets|met|joue|recherche)\\s+"), ""
                ).trim()
                if (query.isNotBlank()) {
                    searchDeezer(query)
                    speak("Je recherche $query sur Deezer")
                } else {
                    speak("Quel morceau veux-tu rechercher ?")
                }
            }
            else -> speak("Je n'ai pas compris. Répète ta demande après Dizeur.")
        }
    }

    private fun noDeezerSession() = "Je ne trouve pas de lecture Deezer active. Ouvre Deezer et lance un titre."

    private fun openDeezer() {
        val launch = packageManager.getLaunchIntentForPackage("deezer.android.app")
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } else {
            searchDeezer("")
        }
    }

    private fun searchDeezer(query: String) {
        val url = if (query.isBlank()) {
            "https://www.deezer.com"
        } else {
            "https://www.deezer.com/search/${Uri.encode(query)}"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Ouverture de Deezer impossible", e)
            speak("Je ne peux pas ouvrir la recherche Deezer.")
        }
    }

    private fun speak(message: String) {
        val engine = tts
        if (!ttsReady || engine == null) {
            scheduleRestart(900)
            return
        }
        speaking = true
        cancelRestart()
        val utteranceId = "dizeur-${System.currentTimeMillis()}"
        val result = engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        if (result == TextToSpeech.ERROR) {
            speaking = false
            scheduleRestart(900)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale.FRANCE)
            ttsReady = languageResult != null &&
                languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    handler.post {
                        speaking = false
                        scheduleRestart(450)
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handleTtsError()
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    handleTtsError()
                }
            })
        } else {
            ttsReady = false
        }
    }

    private fun handleTtsError() {
        handler.post {
            speaking = false
            scheduleRestart(900)
        }
    }

    override fun onDestroy() {
        destroyed = true
        cancelRestart()
        handler.removeCallbacksAndMessages(null)
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Exception) { }
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
